import React from 'react';
import {Text, ScrollView, Button, View, ImageBackground} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import {SharedElement} from 'react-navigation-shared-element';
import {useNavigation} from '@react-navigation/native';

const SinglePost = (props) => {
  const {item} = props?.route?.params;
  const {goBack} = useNavigation();

  return (
    <SafeAreaView>
      <ScrollView>
        <SharedElement id={`item.${item.id}.photo`}>
          <ImageBackground
            source={{uri: item.image}}
            style={{
              width: '100%',
              height: 500,
              justifyContent: 'flex-end',
            }}>
            <View style={{padding: 30}}>
              <Text style={{color: 'white', fontSize: 40}}>{item.title}</Text>
            </View>
          </ImageBackground>
          <View
            style={{
              position: 'absolute',
              right: 20,
              top: 20,
              borderRadius: 20,
              backgroundColor: 'white',
              width: 40,
              height: 40,
            }}>
            <Button title="x" onPress={() => goBack()} />
          </View>
        </SharedElement>
        <SharedElement id={`item.${item.id}.content`}>
          <Text>{item.content}</Text>
        </SharedElement>
      </ScrollView>
    </SafeAreaView>
  );
};

export default SinglePost;
